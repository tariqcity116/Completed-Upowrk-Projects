﻿using MovieSorter;

TestDriver.AddTestClass(typeof(MovieTests));
TestDriver.RunAllTests();