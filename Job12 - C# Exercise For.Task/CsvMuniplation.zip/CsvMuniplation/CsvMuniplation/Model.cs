﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsvMuniplation
{
    public class Model
    {
        public string Fname { get; set; }
        public string Lname { get; set; }
        public string Phone { get; set; }
        public string email { get; set; }
        public string managerEmail { get; set; }
        public int CCID { get; set; }
        public int OC { get; set; }
        public string Country { get; set; }
        public string Active { get; set; }
        public string UG { get; set; }
    }
}
