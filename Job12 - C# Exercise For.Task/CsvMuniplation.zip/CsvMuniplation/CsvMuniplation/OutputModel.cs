﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsvMuniplation
{
    
        public class OutputModel
        {
            public string Fname { get; set; }
            public string Lname { get; set; }
            public string Phone { get; set; }
            public string email { get; set; }
            public string managerEmail { get; set; }

        public string New_Column { get; set; }
        public string Country { get; set; }
            public string Active { get; set; }
            public string UG { get; set; }
        }
    }
