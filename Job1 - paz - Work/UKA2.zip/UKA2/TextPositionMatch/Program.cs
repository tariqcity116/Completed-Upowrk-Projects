﻿class Program
{
    static void Main(string[] args)
    {
        //Console.Write("Please enter the text: ");
        //string text = Console.ReadLine();

        //Console.Write("Please enter the subtext: ");
        //string subtext = Console.ReadLine();

        //Console.Write("Do you want to perform a case-insensitive search? (Y/N): ");
        //string input = Console.ReadLine();

        //bool caseInsensitive = (input.ToLower() == "y");

        ////Matcher matcher = new Matcher(text, subtext, caseInsensitive);
        //List<int> matches = matcher.FindMatches();

        //foreach (int match in matches)
        //{
        //    Console.WriteLine($"Match found at position {match}");
        //}

        //Console.WriteLine("Press any key to exit...");
        //Console.ReadKey();

        //string text = "Hello World";
        //string subText = "or";
        //int subStringIndex = 0;



        //for (int i = 0; i < text.Length; i++)
        //{
        //    if (text[i] == subText[subStringIndex])
        //    {
        //        if (subStringIndex == subText.Length - 1)
        //        {
        //            int index = i - subText.Length + 1;
        //            //Console.WriteLine("Substring '" + subString + "' found at index " + index);

        //            subStringIndex = 0;
        //        }
        //        else
        //        {
        //            subStringIndex++;
        //        }
        //    }
        //    else
        //    {
        //        subStringIndex = 0;
        //    }



        //    if (subStringIndex == 1 && i < text.Length - 1 && text[i + 1] == subText[1])
        //    {
        //        subStringIndex++;
        //    }
        //}
    }
}